from PyQt5 import QtCore, QtGui, QtWidgets

def prevSRTF(self):
    # code
    print("pending")