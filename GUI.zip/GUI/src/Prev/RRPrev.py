from PyQt5 import QtCore, QtGui, QtWidgets

def prevRR(self):
    # code
    print("pending")