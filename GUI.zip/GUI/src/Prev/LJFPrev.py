from PyQt5 import QtCore, QtGui, QtWidgets

def prevLJF(self):
    # code
    print("pending")