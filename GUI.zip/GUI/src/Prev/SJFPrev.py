from PyQt5 import QtCore, QtGui, QtWidgets

def prevSJF(self):
    # code
    print("pending")