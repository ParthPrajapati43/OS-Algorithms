from PyQt5 import QtCore, QtGui, QtWidgets

def prevPriority(self):
    # code
    print("pending")