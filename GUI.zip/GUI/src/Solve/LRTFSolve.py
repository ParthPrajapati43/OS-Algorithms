from PyQt5 import QtCore, QtGui, QtWidgets

def solveLRTF(self):
    self.solveLJF()