from PyQt5 import QtCore, QtGui, QtWidgets

def solveSRTF(self):
    self.solveSJF()