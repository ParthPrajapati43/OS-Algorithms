from PyQt5 import QtCore, QtGui, QtWidgets

def nextSRTF(self):
    # code
    print("pending")