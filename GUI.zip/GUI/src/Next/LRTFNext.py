from PyQt5 import QtCore, QtGui, QtWidgets

def nextLRTF(self):
    # code
    print("pending")