from PyQt5 import QtCore, QtGui, QtWidgets

def nextRR(self):
    # code
    print("pending")