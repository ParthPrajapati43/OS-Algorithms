from PyQt5 import QtCore, QtGui, QtWidgets

def nextLJF(self):
    # code
    print("pending")