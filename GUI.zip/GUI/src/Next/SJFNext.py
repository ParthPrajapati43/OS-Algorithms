from PyQt5 import QtCore, QtGui, QtWidgets

def nextSJF(self):
    # code
    print("pending")