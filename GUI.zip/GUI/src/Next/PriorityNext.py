from PyQt5 import QtCore, QtGui, QtWidgets

def nextPriority(self):
    # code
    print("pending")