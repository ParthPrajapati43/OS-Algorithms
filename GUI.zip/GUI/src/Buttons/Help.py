from PyQt5 import QtCore, QtGui, QtWidgets

def helpBtnHandler(self):
    # code
    print("pending")